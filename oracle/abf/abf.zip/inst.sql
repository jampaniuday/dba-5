select instance_name from v$instance;
