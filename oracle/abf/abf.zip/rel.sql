select release_name from fnd_product_groups;
