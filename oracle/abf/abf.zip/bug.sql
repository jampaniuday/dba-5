select * from ad_bugs where bug_number = '&bug';
